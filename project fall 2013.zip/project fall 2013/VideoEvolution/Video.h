#pragma once
#include <vector>
#include "cv.h"
#include "highgui.h"
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include "Frame.h"
#include <map>

using namespace std;
using namespace cv;

class Video
{
private:
	vector<Frame> framelist;
	string name;
	int vid;
	
public:	
	string path;
	map<int,int> clustered_frame; // video representation map<frame_label, count>
	int frameno; //all the frames extracted from video (1 frame per second)
	int height;
	int width;

	Video(string path, string name, int vid);
	~Video(void);

	string GetVideoName();
	void SetVideoName(string name);
	vector<Frame> GetFrameList();

	void SetMap(int fid);
	int GetVID();
};

